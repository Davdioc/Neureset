#ifndef LENSTEST_H
#define LENSTEST_H

#include <QObject>

class lensTest : public QObject
{
    Q_OBJECT

public:
    explicit lensTest(QObject *parent = nullptr);
    void performTest();

signals:

};

#endif // LENSTEST_H
