#ifndef DEFS_H
#define DEFS_H

#define DEBUG_OUTPUTS true
#define SYSTEM_OUTPUTS true

#include <string>
#include <iostream>

using namespace std;

#endif // DEFS_H
