#include "lenstest.h"

lensTest::lensTest(QObject *parent)
    : QObject{parent}
{

}
