--After April 2nd--
Stopped tracking meetings, contributions visible on github.

--April 2nd--
Members present: Noah, Mahmud, Sam
Git push/pull branch cmds practice


--April 1st--
Members present: Noah, Mahmud, Sam
Calendar layout for anticipated project deadlines.
  Rough demo tbc April 5th
  Diagrams tbc April 8th
Prepping on private access to repo on course VM

--March 27th--
Members present: Noah, Mahmud, Sam, Dave
Use Cases creation: Noah, Mahmud, Sam
To be completed by Mahmud.
Next session planned for March 29th -Delayed to April 1st

--March 22nd--
Members present: All
Have project specs read and have idea for class diagram config

Team Members: Noah Gam, Mahmud Ali, Samuel Abraham, Emioluwa Oguntunde, David Oche

Samuel was responsible for implementation of the UI - mainUI class, timer class, devpanel, pcUI, and mainControl class.
Noah was responsible for the implementation of the lenstest code, including the lensTest class, electrode class, eegwavetransformgenerator class, countdowntimer class, databasemanager class. Also contributed to timer class.
Emioluwa Oguntunde was responsible for the state diagram and will be implementing the exporting database, and the battery low response sequence diagram.
David was responsible for the UML diagram and the rest of the sequence diagrams
Mahmud was responsible for the Use cases and the traceability matrix, helped with bug fixes and making changes to the waveform generation and implementing date and time functions. He also did the design choice document.

Submission organization:
All the code and project files are within CodeBase/Neuraset
Diagrams are within the diagrams folder
Documentation contained in documentation folder

Youtube link: https://youtu.be/7yt1WKRaV1w
